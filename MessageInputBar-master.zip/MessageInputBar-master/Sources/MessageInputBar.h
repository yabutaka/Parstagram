//
//  MessageInputBar.h
//  MessageInputBar
//
//  Created by Nathan Tannar on 2018-06-03.
//  Copyright © 2018 MessageKit. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MessageInputBar.
FOUNDATION_EXPORT double MessageInputBarVersionNumber;

//! Project version string for MessageInputBar.
FOUNDATION_EXPORT const unsigned char MessageInputBarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MessageInputBar/PublicHeader.h>


